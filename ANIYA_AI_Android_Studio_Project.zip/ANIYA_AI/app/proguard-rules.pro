# Proguard rules for ANIYA AI
-keep class com.google.ai.client.generativeai.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.aniya.ai.data.model.** { *; }
