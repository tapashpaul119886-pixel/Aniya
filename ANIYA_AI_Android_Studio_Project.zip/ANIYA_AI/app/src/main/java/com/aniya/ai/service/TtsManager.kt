package com.aniya.ai.service

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

class TtsManager(
    private val context: Context,
    private val onSpeakingStarted: () -> Unit = {},
    private val onSpeakingFinished: () -> Unit = {}
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            setupVoice()

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    onSpeakingStarted()
                }

                override fun onDone(utteranceId: String?) {
                    onSpeakingFinished()
                }

                override fun onError(utteranceId: String?) {
                    onSpeakingFinished()
                }
            })
        }
    }

    private fun setupVoice() {
        val ttsInstance = tts ?: return
        val hindiLocale = Locale("hi", "IN")
        val enInLocale = Locale("en", "IN")

        if (ttsInstance.isLanguageAvailable(hindiLocale) >= TextToSpeech.LANG_AVAILABLE) {
            ttsInstance.language = hindiLocale
        } else {
            ttsInstance.language = enInLocale
        }

        try {
            val voices = ttsInstance.voices
            val femaleVoice = voices?.firstOrNull { voice ->
                (voice.locale.language == "hi" || voice.locale.country == "IN") &&
                        voice.name.contains("female", ignoreCase = true)
            } ?: voices?.firstOrNull { voice -> voice.locale.country == "IN" }
            
            if (femaleVoice != null) {
                ttsInstance.voice = femaleVoice
            }
        } catch (e: Exception) { }

        ttsInstance.setPitch(1.05f)
        ttsInstance.setSpeechRate(0.98f)
    }

    fun speak(text: String, utteranceId: String = "ANIYA_UTTERANCE") {
        if (!isInitialized || tts == null) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
