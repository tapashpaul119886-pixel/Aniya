package com.aniya.ai.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import java.util.Locale

class VoiceService(
    private val context: Context,
    private val onWakeWordDetected: () -> Unit,
    private val onSpeechRecognized: (String) -> Unit,
    private val onRmsChangedCallback: (Float) -> Unit = {},
    private val onErrorOccurred: (String) -> Unit = {}
) {

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var isContinuousListeningEnabled = true

    init {
        initRecognizer()
    }

    private fun initRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.e("VoiceService", "Speech recognition not available on this device")
            onErrorOccurred("Is phone me Speech Recognition uplabdh nahi hai.")
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {
                    onRmsChangedCallback(rmsdB)
                }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    val errorMessage = getErrorText(error)
                    isListening = false

                    if (isContinuousListeningEnabled && (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) {
                        startContinuousListening()
                    } else {
                        onErrorOccurred(errorMessage)
                    }
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.trim() ?: ""

                    if (text.isNotBlank()) {
                        val normalized = text.lowercase(Locale.ROOT)
                        if (normalized.contains("aniya") || normalized.contains("अनिया") || normalized.contains("ania")) {
                            onWakeWordDetected()
                            onSpeechRecognized(text)
                        } else {
                            onSpeechRecognized(text)
                        }
                    }

                    if (isContinuousListeningEnabled) {
                        startContinuousListening()
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partialMatches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partialText = partialMatches?.firstOrNull()?.lowercase(Locale.ROOT) ?: ""

                    if (partialText.contains("aniya") || partialText.contains("अनिया") || partialText.contains("ania")) {
                        onWakeWordDetected()
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    fun startContinuousListening() {
        if (isListening || speechRecognizer == null) return

        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayListOf("hi-IN", "en-IN", "en-US"))
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }

            speechRecognizer?.startListening(intent)
            isListening = true
        } catch (e: Exception) {
            isListening = false
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) { }
        isListening = false
    }

    fun destroy() {
        isContinuousListeningEnabled = false
        stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun getErrorText(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
            SpeechRecognizer.ERROR_NETWORK -> "Network error"
            SpeechRecognizer.ERROR_NO_MATCH -> "Kuch suna nahi diya"
            else -> "Awaaz pehchanne me samasya ($errorCode)"
        }
    }
}
