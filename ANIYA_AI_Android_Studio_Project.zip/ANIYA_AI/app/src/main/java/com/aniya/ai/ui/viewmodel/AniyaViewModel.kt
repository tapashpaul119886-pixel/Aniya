package com.aniya.ai.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aniya.ai.action.ActionResult
import com.aniya.ai.action.ContactMatch
import com.aniya.ai.action.PhoneActionExecutor
import com.aniya.ai.data.gemini.GeminiClient
import com.aniya.ai.data.model.AssistantState
import com.aniya.ai.data.model.ChatMessage
import com.aniya.ai.data.model.Sender
import com.aniya.ai.service.TtsManager
import com.aniya.ai.service.VoiceService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AniyaViewModel(application: Application) : AndroidViewModel(application) {

    private val geminiClient = GeminiClient()
    private val actionExecutor = PhoneActionExecutor(application)

    private val _assistantState = MutableStateFlow(AssistantState.IDLE)
    val assistantState: StateFlow<AssistantState> = _assistantState.asStateFlow()

    private val _statusText = MutableStateFlow("“Aniya” bolen ya mic button dabayein")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = Sender.ANIYA,
                text = "Namaste! Main ANIYA hoon. Main aapki kya madad kar sakti hoon?"
            )
        )
    )
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()

    private val _rmsDb = MutableStateFlow(0f)
    val rmsDb: StateFlow<Float> = _rmsDb.asStateFlow()

    private val _multipleContacts = MutableStateFlow<List<ContactMatch>?>(null)
    val multipleContacts: StateFlow<List<ContactMatch>?> = _multipleContacts.asStateFlow()

    private val _pendingPermission = MutableStateFlow<String?>(null)
    val pendingPermission: StateFlow<String?> = _pendingPermission.asStateFlow()

    private var ttsManager: TtsManager? = null
    private var voiceService: VoiceService? = null

    init {
        initTts()
        initVoice()
    }

    private fun initTts() {
        ttsManager = TtsManager(
            context = getApplication(),
            onSpeakingStarted = {
                _assistantState.value = AssistantState.SPEAKING
            },
            onSpeakingFinished = {
                _assistantState.value = AssistantState.IDLE
                _statusText.value = "“Aniya” bolen ya mic dabayein"
            }
        )
    }

    private fun initVoice() {
        voiceService = VoiceService(
            context = getApplication(),
            onWakeWordDetected = {
                _assistantState.value = AssistantState.LISTENING
                _statusText.value = "Sun rahi hoon..."
            },
            onSpeechRecognized = { text ->
                handleUserVoiceInput(text)
            },
            onRmsChangedCallback = { rms ->
                _rmsDb.value = rms
            },
            onErrorOccurred = { error ->
                Log.w("AniyaViewModel", "Voice error: $error")
            }
        )
    }

    fun startListeningManual() {
        ttsManager?.stop()
        _assistantState.value = AssistantState.LISTENING
        _statusText.value = "Sun rahi hoon..."
        voiceService?.startContinuousListening()
    }

    fun stopListeningManual() {
        voiceService?.stopListening()
        _assistantState.value = AssistantState.IDLE
        _statusText.value = "“Aniya” bolen ya mic dabayein"
    }

    fun handleUserVoiceInput(userInput: String) {
        val cleanInput = userInput.trim()
        if (cleanInput.isBlank()) return

        val userMsg = ChatMessage(sender = Sender.USER, text = cleanInput)
        _chatHistory.value = _chatHistory.value + userMsg

        _assistantState.value = AssistantState.THINKING
        _statusText.value = "Soch rahi hoon..."

        viewModelScope.launch {
            val lower = cleanInput.lowercase()
            if (lower.contains("time") && (lower.contains("kya hua") || lower.contains("batao") || lower.contains("kya hai"))) {
                val timeReply = actionExecutor.getCurrentTime()
                speakAndRespond(timeReply, "GET_TIME")
                return@launch
            }

            if (lower.contains("battery") && (lower.contains("kitni") || lower.contains("status") || lower.contains("kya hai"))) {
                val batteryReply = actionExecutor.getBatteryStatus()
                speakAndRespond(batteryReply, "GET_BATTERY")
                return@launch
            }

            val result = geminiClient.processCommand(cleanInput)
            result.onSuccess { response ->
                var actionExecutionNote: String? = null

                when (response.action) {
                    "OPEN_APP" -> {
                        val appName = response.actionParams?.appName ?: "app"
                        val actionResult = actionExecutor.openApp(appName)
                        handleActionResult(actionResult)
                        actionExecutionNote = "Action: App $appName"
                    }
                    "CALL_CONTACT" -> {
                        val contactName = response.actionParams?.contactName ?: ""
                        if (contactName.isNotBlank()) {
                            val actionResult = actionExecutor.callContact(contactName)
                            handleActionResult(actionResult)
                            actionExecutionNote = "Action: Call $contactName"
                        }
                    }
                    "SET_ALARM" -> {
                        val actionResult = actionExecutor.setAlarm(response.actionParams?.time)
                        handleActionResult(actionResult)
                        actionExecutionNote = "Action: Alarm ${response.actionParams?.time}"
                    }
                    "SET_TIMER" -> {
                        val actionResult = actionExecutor.setTimer(response.actionParams?.seconds)
                        handleActionResult(actionResult)
                        actionExecutionNote = "Action: Timer ${response.actionParams?.seconds}s"
                    }
                    "GET_TIME" -> {
                        val reply = actionExecutor.getCurrentTime()
                        speakAndRespond(reply, "GET_TIME")
                        return@launch
                    }
                    "GET_BATTERY" -> {
                        val reply = actionExecutor.getBatteryStatus()
                        speakAndRespond(reply, "GET_BATTERY")
                        return@launch
                    }
                }

                speakAndRespond(response.speechText, actionExecutionNote)

            }.onFailure { error ->
                _assistantState.value = AssistantState.ERROR
                val errorMsg = error.message ?: "Kshama karein, kuch asuvidha hui."
                _statusText.value = errorMsg
                speakAndRespond(errorMsg, "ERROR")
            }
        }
    }

    private fun handleActionResult(actionResult: ActionResult) {
        when (actionResult) {
            is ActionResult.Success -> {
                Log.d("AniyaViewModel", "Action success: ${actionResult.message}")
            }
            is ActionResult.PermissionNeeded -> {
                _pendingPermission.value = actionResult.permission
            }
            is ActionResult.MultipleContactsFound -> {
                _multipleContacts.value = actionResult.contacts
                speakAndRespond("Rahul naam ke kayi contact mile. Kripya chuniye kaunse Rahul ko call lagana hai.", "MULTIPLE_CONTACTS")
            }
            is ActionResult.Error -> {
                Log.w("AniyaViewModel", "Action error: ${actionResult.message}")
            }
        }
    }

    fun selectContactToCall(contact: ContactMatch) {
        _multipleContacts.value = null
        val result = actionExecutor.initiateCall(contact)
        handleActionResult(result)
        speakAndRespond("${contact.name} ko call lagayi ja rahi hai.", "CALL_INITIATED")
    }

    fun dismissContactsChooser() {
        _multipleContacts.value = null
    }

    fun clearPendingPermission() {
        _pendingPermission.value = null
    }

    private fun speakAndRespond(text: String, actionNote: String? = null) {
        val aniyaMsg = ChatMessage(
            sender = Sender.ANIYA,
            text = text,
            actionExecuted = actionNote
        )
        _chatHistory.value = _chatHistory.value + aniyaMsg

        _assistantState.value = AssistantState.SPEAKING
        _statusText.value = text
        ttsManager?.speak(text)
    }

    fun clearChat() {
        _chatHistory.value = emptyList()
    }

    override fun onCleared() {
        super.onCleared()
        voiceService?.destroy()
        ttsManager?.shutdown()
    }
}
