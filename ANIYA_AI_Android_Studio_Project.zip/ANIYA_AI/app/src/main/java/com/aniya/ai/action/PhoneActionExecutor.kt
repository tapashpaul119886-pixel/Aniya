package com.aniya.ai.action

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ContactMatch(
    val name: String,
    val phoneNumber: String
)

sealed class ActionResult {
    data class Success(val message: String) : ActionResult()
    data class PermissionNeeded(val permission: String, val explanation: String) : ActionResult()
    data class MultipleContactsFound(val contacts: List<ContactMatch>) : ActionResult()
    data class Error(val message: String) : ActionResult()
}

class PhoneActionExecutor(private val context: Context) {

    fun openApp(appName: String): ActionResult {
        val target = appName.lowercase(Locale.ROOT).trim()

        return when {
            target.contains("whatsapp") -> launchPackageOrStore("com.whatsapp", "WhatsApp")
            target.contains("youtube") -> launchPackageOrStore("com.google.android.youtube", "YouTube")
            target.contains("facebook") -> launchPackageOrStore("com.facebook.katana", "Facebook")
            target.contains("instagram") -> launchPackageOrStore("com.instagram.android", "Instagram")
            target.contains("camera") || target.contains("kamera") -> launchCamera()
            target.contains("setting") -> launchSettings()
            target.contains("contact") -> launchContacts()
            target.contains("dialer") || target.contains("phone") -> launchDialer()
            else -> {
                val pm = context.packageManager
                val intent = pm.getLaunchIntentForPackage(target)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    ActionResult.Success("$appName khol diya gaya hai.")
                } else {
                    ActionResult.Error("Aapke phone me $appName application installed nahi mila.")
                }
            }
        }
    }

    private fun launchPackageOrStore(packageName: String, readableName: String): ActionResult {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(packageName)
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionResult.Success("$readableName khol rahi hoon.")
        } else {
            try {
                val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(storeIntent)
                ActionResult.Success("$readableName phone me nahi mila, Play Store par khol rahi hoon.")
            } catch (e: Exception) {
                ActionResult.Error("$readableName phone me installed nahi hai.")
            }
        }
    }

    private fun launchCamera(): ActionResult {
        return try {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResult.Success("Camera khol rahi hoon.")
        } catch (e: Exception) {
            ActionResult.Error("Camera open karne me samasya aayi.")
        }
    }

    private fun launchSettings(): ActionResult {
        return try {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResult.Success("Settings open kar diya hai.")
        } catch (e: Exception) {
            ActionResult.Error("Settings open nahi ho paaya.")
        }
    }

    private fun launchContacts(): ActionResult {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResult.Success("Contacts khol rahi hoon.")
        } catch (e: Exception) {
            ActionResult.Error("Contacts open nahi ho paaya.")
        }
    }

    private fun launchDialer(): ActionResult {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResult.Success("Phone dialer open kar diya hai.")
        } catch (e: Exception) {
            ActionResult.Error("Dialer open nahi ho paaya.")
        }
    }

    fun callContact(contactName: String): ActionResult {
        val hasContactsPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasContactsPermission) {
            return ActionResult.PermissionNeeded(
                permission = Manifest.permission.READ_CONTACTS,
                explanation = "$contactName ko call lagane ke liye Contacts permission ki aavashyakta hai."
            )
        }

        val matches = searchContacts(contactName)

        return when {
            matches.isEmpty() -> {
                ActionResult.Error("Contacts me '$contactName' naam ka koi contact nahi mila.")
            }
            matches.size == 1 -> {
                initiateCall(matches.first())
            }
            else -> {
                ActionResult.MultipleContactsFound(matches)
            }
        }
    }

    private fun searchContacts(queryName: String): List<ContactMatch> {
        val contactList = mutableListOf<ContactMatch>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$queryName%")

        var cursor: Cursor? = null
        try {
            cursor = context.contentResolver.query(uri, projection, selection, selectionArgs, null)
            cursor?.let {
                val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                while (it.moveToNext()) {
                    val name = it.getString(nameIndex) ?: ""
                    val number = it.getString(numberIndex) ?: ""
                    if (name.isNotBlank() && number.isNotBlank() && contactList.none { c -> c.phoneNumber == number }) {
                        contactList.add(ContactMatch(name, number))
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            cursor?.close()
        }

        return contactList
    }

    fun initiateCall(contact: ContactMatch): ActionResult {
        val hasCallPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val intent = if (hasCallPermission) {
            Intent(Intent.ACTION_CALL, Uri.parse("tel:${contact.phoneNumber}"))
        } else {
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.phoneNumber}"))
        }.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            ActionResult.Success("${contact.name} ko call lagayi ja rahi hai (${contact.phoneNumber}).")
        } catch (e: Exception) {
            ActionResult.Error("Call initiate nahi ho payi.")
        }
    }

    fun setAlarm(timeString: String?, message: String? = "ANIYA Alarm"): ActionResult {
        val timeParts = timeString?.split(":")
        val hour = timeParts?.getOrNull(0)?.toIntOrNull() ?: 7
        val minute = timeParts?.getOrNull(1)?.toIntOrNull() ?: 0

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, message ?: "ANIYA Alarm")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            val formattedTime = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
            ActionResult.Success("$formattedTime baje ka alarm set kar diya gaya hai.")
        } catch (e: Exception) {
            ActionResult.Error("Alarm lagane ke liye Clock app nahi mila.")
        }
    }

    fun setTimer(seconds: Int?): ActionResult {
        val duration = seconds ?: 60
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, duration)
            putExtra(AlarmClock.EXTRA_MESSAGE, "ANIYA Timer")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            val minutes = duration / 60
            val remSec = duration % 60
            val timeDesc = if (minutes > 0) "$minutes minute ${if (remSec > 0) "$remSec second" else ""}" else "$duration second"
            ActionResult.Success("$timeDesc ka timer shuru kar diya gaya hai.")
        } catch (e: Exception) {
            ActionResult.Error("Timer shuru karne ke liye application nahi mila.")
        }
    }

    fun getCurrentTime(): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val formatted = sdf.format(Date())
        return "Abhi samay $formatted hua hai."
    }

    fun getBatteryStatus(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val batteryPct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val isCharging = bm?.isCharging ?: false

        return if (batteryPct >= 0) {
            val status = if (isCharging) "charging par laga hai" else "charging par nahi hai"
            "Aapke phone ki battery $batteryPct% hai aur $status."
        } else {
            "Battery ki jaankari prapt nahi ho saki."
        }
    }
}
