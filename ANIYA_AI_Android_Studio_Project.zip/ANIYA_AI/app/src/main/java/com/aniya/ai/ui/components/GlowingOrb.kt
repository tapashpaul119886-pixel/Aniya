package com.aniya.ai.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.aniya.ai.data.model.AssistantState
import com.aniya.ai.ui.theme.NeonAmber
import com.aniya.ai.ui.theme.NeonCyan
import com.aniya.ai.ui.theme.NeonEmerald
import com.aniya.ai.ui.theme.NeonMagenta
import com.aniya.ai.ui.theme.NeonPurple
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GlowingOrb(
    state: AssistantState,
    rmsDb: Float = 0f,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orbTransition")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (state == AssistantState.THINKING) 800 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (state == AssistantState.THINKING) 2500 else 8000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    val ringExpand by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ringExpand"
    )

    val primaryColor by animateColorAsState(
        targetValue = when (state) {
            AssistantState.IDLE -> NeonCyan
            AssistantState.LISTENING -> NeonEmerald
            AssistantState.THINKING -> NeonPurple
            AssistantState.SPEAKING -> NeonMagenta
            AssistantState.ERROR -> NeonAmber
        },
        label = "primaryColor"
    )

    val secondaryColor by animateColorAsState(
        targetValue = when (state) {
            AssistantState.IDLE -> Color(0xFF1E3A8A)
            AssistantState.LISTENING -> NeonCyan
            AssistantState.THINKING -> NeonMagenta
            AssistantState.SPEAKING -> NeonPurple
            AssistantState.ERROR -> Color(0xFFE11D48)
        },
        label = "secondaryColor"
    )

    Box(
        modifier = modifier.size(240.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(220.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            val baseRadius = (size.minDimension / 3.4f) * pulseScale

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.45f),
                        secondaryColor.copy(alpha = 0.20f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.8f
                ),
                radius = baseRadius * 1.8f,
                center = center
            )

            if (state == AssistantState.LISTENING || state == AssistantState.SPEAKING) {
                drawCircle(
                    color = primaryColor.copy(alpha = (1.4f - ringExpand).coerceIn(0f, 0.7f)),
                    radius = baseRadius * ringExpand,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
            }

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.95f),
                        primaryColor.copy(alpha = 0.90f),
                        secondaryColor.copy(alpha = 0.85f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius
                ),
                radius = baseRadius,
                center = center
            )

            val particleCount = if (state == AssistantState.THINKING) 6 else 4
            val radAngle = Math.toRadians(rotation.toDouble())
            for (i in 0 until particleCount) {
                val offsetAngle = radAngle + (i * (2 * Math.PI / particleCount))
                val orbitDist = baseRadius * 1.18f
                val px = center.x + (orbitDist * cos(offsetAngle)).toFloat()
                val py = center.y + (orbitDist * sin(offsetAngle)).toFloat()

                drawCircle(
                    color = if (i % 2 == 0) primaryColor else Color.White,
                    radius = if (state == AssistantState.THINKING) 5.dp.toPx() else 3.5.dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }
    }
}
