package com.aniya.ai.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00F0FF)
val NeonPurple = Color(0xFFB026FF)
val NeonMagenta = Color(0xFFFF007F)
val NeonEmerald = Color(0xFF00FF9D)
val NeonAmber = Color(0xFFFFB800)

val DarkBackground = Color(0xFF08090E)
val DarkSurface = Color(0xFF111420)
val DarkSurfaceElevated = Color(0xFF191E30)
val DarkBorder = Color(0xFF262C44)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
