package com.aniya.ai.data.model

import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionExecuted: String? = null
)

enum class Sender {
    USER,
    ANIYA
}
