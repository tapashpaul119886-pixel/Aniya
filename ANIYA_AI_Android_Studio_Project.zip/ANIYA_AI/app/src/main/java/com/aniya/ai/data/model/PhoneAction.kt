package com.aniya.ai.data.model

import com.google.gson.annotations.SerializedName

enum class ActionType {
    OPEN_APP,
    CALL_CONTACT,
    SET_ALARM,
    SET_TIMER,
    GET_TIME,
    GET_BATTERY,
    NONE
}

data class ActionParams(
    @SerializedName("appName") val appName: String? = null,
    @SerializedName("contactName") val contactName: String? = null,
    @SerializedName("time") val time: String? = null,
    @SerializedName("seconds") val seconds: Int? = null,
    @SerializedName("query") val query: String? = null
)

data class AniyaResponse(
    @SerializedName("speechText") val speechText: String,
    @SerializedName("action") val action: String = "NONE",
    @SerializedName("actionParams") val actionParams: ActionParams? = null
)
