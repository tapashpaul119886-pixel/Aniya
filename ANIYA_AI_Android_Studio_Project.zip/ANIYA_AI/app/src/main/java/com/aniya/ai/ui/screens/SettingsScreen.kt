package com.aniya.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aniya.ai.BuildConfig
import com.aniya.ai.ui.theme.*
import com.aniya.ai.ui.viewmodel.AniyaViewModel

@Composable
fun SettingsScreen(viewModel: AniyaViewModel) {
    val scrollState = rememberScrollState()
    var wakeWordEnabled by remember { mutableStateOf(true) }
    var femaleVoiceEnabled by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        Text(
            text = "ANIYA Settings",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Text(
            text = "Voice Assistant and System Configuration",
            fontSize = 13.sp,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(20.dp))

        SettingsCard(title = "Wake Word & Recognition", icon = Icons.Default.Mic) {
            SettingToggleItem(
                title = "Foreground Wake Word (\"Aniya\")",
                description = "App open hone par 'Aniya' kehne par turant activate ho.",
                checked = wakeWordEnabled,
                onCheckedChange = { wakeWordEnabled = it }
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceElevated)
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Notice",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Android Privacy Note: Background me 24/7 mic khula rakhna battery aur OS policy ke anusaar restricted hai. Isliye wake word foreground active app par safely chalta hai.",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        SettingsCard(title = "Voice & Language (TTS)", icon = Icons.Default.RecordVoiceOver) {
            SettingToggleItem(
                title = "Natural Female Voice (Hindi/English)",
                description = "Pehle se behtar female tonal speech engine ka prayog karein.",
                checked = femaleVoiceEnabled,
                onCheckedChange = { femaleVoiceEnabled = it }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        SettingsCard(title = "AI Brain Configuration", icon = Icons.Default.Key) {
            val hasKey = BuildConfig.GEMINI_API_KEY.isNotBlank()
            Text(
                text = if (hasKey) "✓ API Key BuildConfig ke dwara surakshit tareeqe se loaded hai."
                else "⚠ API Key local.properties me GEMINI_API_KEY ke roop me add karein.",
                fontSize = 12.sp,
                color = if (hasKey) NeonEmerald else Color(0xFFEF4444)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        SettingsCard(title = "Security & Permissions", icon = Icons.Default.Security) {
            val permissions = listOf(
                "Microphone" to "Voice command sunne ke liye",
                "Contacts" to "\"Rahul ko call lagao\" command ke liye",
                "Phone Dialer" to "Call dial karne ke liye",
                "Alarm & Clock" to "Alarm aur Timer lagane ke liye"
            )

            permissions.forEach { (perm, desc) ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = perm, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                        Text(text = desc, fontSize = 11.sp, color = TextMuted)
                    }
                    Box(
                        modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(DarkSurfaceElevated).padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(text = "On Demand", fontSize = 10.sp, color = NeonCyan)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
private fun SettingsCard(title: String, icon: ImageVector, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, DarkBorder, RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = title, tint = NeonCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun SettingToggleItem(title: String, description: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Text(text = description, fontSize = 12.sp, color = TextMuted, lineHeight = 16.sp)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = DarkBackground,
                checkedTrackColor = NeonCyan,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = DarkSurfaceElevated
            )
        )
    }
}
