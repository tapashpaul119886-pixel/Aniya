package com.aniya.ai.data.gemini

import com.aniya.ai.BuildConfig
import com.aniya.ai.data.model.ActionParams
import com.aniya.ai.data.model.AniyaResponse
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.generationConfig
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GeminiClient {

    private val gson = Gson()

    private val systemInstructionText = """
        You are ANIYA (अनिया), a smart, warm, friendly female voice assistant for Android.
        The user interacts with you in Hindi, English, or Hinglish (Hindi written in Latin script).
        
        CRITICAL RULES:
        1. Keep responses short and conversational (1-2 sentences max) suitable for direct speech output.
        2. Detect user intentions for phone actions:
           - "OPEN_APP": appName (e.g., "whatsapp", "youtube", "facebook", "instagram", "camera", "settings", "contacts", "dialer")
           - "CALL_CONTACT": contactName (e.g., "Rahul", "Pooja", "Mom")
           - "SET_ALARM": time in "HH:mm" (24hr or 12hr)
           - "SET_TIMER": seconds (integer)
           - "GET_TIME": time query
           - "GET_BATTERY": battery query
           - "NONE": general questions, chit-chat, knowledge
        
        Respond ONLY in valid JSON matching this schema:
        {
          "speechText": "Natural female voice reply in Hindi or Hinglish",
          "action": "OPEN_APP | CALL_CONTACT | SET_ALARM | SET_TIMER | GET_TIME | GET_BATTERY | NONE",
          "actionParams": {
            "appName": "whatsapp",
            "contactName": "Rahul",
            "time": "05:00",
            "seconds": 600
          }
        }
    """.trimIndent()

    private val generativeModel: GenerativeModel by lazy {
        GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = BuildConfig.GEMINI_API_KEY,
            generationConfig = generationConfig {
                temperature = 0.7f
                topK = 40
                topP = 0.95f
                responseMimeType = "application/json"
            },
            systemInstruction = com.google.ai.client.generativeai.type.content {
                text(systemInstructionText)
            }
        )
    }

    suspend fun processCommand(userPrompt: String): Result<AniyaResponse> = withContext(Dispatchers.IO) {
        if (BuildConfig.GEMINI_API_KEY.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API Key missing! Kripya local.properties me GEMINI_API_KEY add karein.")
            )
        }

        try {
            val response = generativeModel.generateContent(userPrompt)
            val jsonText = response.text ?: ""
            
            val parsedResponse = try {
                gson.fromJson(jsonText, AniyaResponse::class.java)
            } catch (e: Exception) {
                AniyaResponse(
                    speechText = jsonText.ifBlank { "Ji, main sun rahi hoon." },
                    action = "NONE",
                    actionParams = null
                )
            }

            Result.success(parsedResponse)
        } catch (e: com.google.ai.client.generativeai.type.GoogleGenerativeAIException) {
            val errorMsg = when {
                e.message?.contains("API_KEY_INVALID", ignoreCase = true) == true -> 
                    "Aapki Gemini API key invalid hai. Kripya check karein."
                e.message?.contains("RESOURCE_EXHAUSTED", ignoreCase = true) == true -> 
                    "API quota exceed ho gaya hai. Kripya kuch samay baad prayas karein."
                else -> "Gemini service se sampark nahi ho saka: ${e.localizedMessage}"
            }
            Result.failure(Exception(errorMsg, e))
        } catch (e: java.io.IOException) {
            Result.failure(Exception("Internet connection uplabdh nahi hai. Kripya apna network check karein.", e))
        } catch (e: Exception) {
            Result.failure(Exception("Kuch gadbad hui: ${e.localizedMessage}", e))
        }
    }
}
