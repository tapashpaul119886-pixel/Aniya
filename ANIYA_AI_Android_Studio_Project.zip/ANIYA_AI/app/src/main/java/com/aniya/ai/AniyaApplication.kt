package com.aniya.ai

import android.app.Application

class AniyaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
