# ANIYA AI - Android Voice Assistant Project

Yeh project Android Studio ke liye poori tarah ready hai.

## Quick Setup:
1. Is ZIP ko extract karein.
2. Android Studio me "Open" par click karein aur extracted 'ANIYA_AI' folder select karein.
3. 'local.properties' file banayein (agar pehle se na ho) aur apni Gemini API Key paste karein:
   GEMINI_API_KEY=AIzaSyAapkiKeyHere
4. Gradle Sync hone dein.
5. "Run" button (Shift+F10) dabayein ya Build > Build APK karein!
